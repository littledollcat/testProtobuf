from sample_module import sample_func
if __name__ == '__main__':
    sample_func()